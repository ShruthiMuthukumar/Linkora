import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';

const TYPES = ['', 'full-time', 'part-time', 'daily-wage', 'internship', 'volunteer'];

export default function Jobs({ user }) {
  const [jobs, setJobs] = useState([]);
  const [q, setQ] = useState('');
  const [type, setType] = useState('');
  const [msg, setMsg] = useState('');

  useEffect(() => {
    const t = setTimeout(() => {
      api(`/jobs?q=${encodeURIComponent(q)}&type=${type}`).then(setJobs).catch((e) => setMsg(e.message));
    }, 250);
    return () => clearTimeout(t);
  }, [q, type]);

  const apply = async (id) => {
    try {
      await api(`/jobs/${id}/apply`, { method: 'POST' });
      setJobs(jobs.map((j) => (j._id === id ? { ...j, applied: true, applicantCount: j.applicantCount + 1 } : j)));
    } catch (e) { setMsg(e.message); }
  };

  return (
    <>
      <h1>Find work near you</h1>
      <div className="filters">
        <input type="search" placeholder="Job, place or skill" aria-label="Search jobs" value={q} onChange={(e) => setQ(e.target.value)} />
        <select aria-label="Job type" value={type} onChange={(e) => setType(e.target.value)}>
          {TYPES.map((t) => <option key={t} value={t}>{t || 'All types'}</option>)}
        </select>
      </div>
      {msg && <p className="error" role="alert">{msg}</p>}
      {!jobs.length && <p className="card">No jobs found. Try a different word or choose “All types”.</p>}
      {jobs.map((j) => (
        <article className="card job" key={j._id}>
          <div>
            <h2>{j.title}</h2>
            <p className="mute">{j.company} · {j.location}</p>
            <p><span className="tag">{j.type}</span>{j.pay && <strong>{j.pay}</strong>}</p>
            <p>{j.description}</p>
            {j.skills.map((s) => <span className="tag soft" key={s}>{s}</span>)}
          </div>
          {user
            ? <button className={`btn ${j.applied ? 'done' : ''}`} disabled={j.applied} onClick={() => apply(j._id)}>{j.applied ? '✔ Applied' : 'Apply'}</button>
            : <Link className="btn ghost" to="/login">Log in to apply</Link>}
        </article>
      ))}
    </>
  );
}
