import { useEffect, useState } from 'react';
import { api } from '../api';

export default function Learn({ user, refresh }) {
  const [courses, setCourses] = useState([]);
  const [open, setOpen] = useState(null);
  const [err, setErr] = useState('');

  useEffect(() => { api('/courses').then(setCourses).catch((e) => setErr(e.message)); }, []);
  const done = (id) => user && user.completed.includes(id);

  const complete = async (id) => {
    try { await api(`/courses/${id}/complete`, { method: 'POST' }); await refresh(); }
    catch (e) { setErr(e.message); }
  };

  return (
    <>
      <h1>Learn new skills</h1>
      <p className="mute">Short lessons in simple words. Finish a course to add it to your profile.</p>
      {err && <p className="error" role="alert">{err}</p>}
      <div className="grid">
        {courses.map((c) => (
          <article className="card" key={c._id}>
            <div className="big-icon" aria-hidden>{c.icon}</div>
            <h2>{c.title}</h2>
            <p className="mute">{c.category} · {c.level}</p>
            <p>{c.description}</p>
            <button className="btn ghost" aria-expanded={open === c._id} onClick={() => setOpen(open === c._id ? null : c._id)}>
              {open === c._id ? 'Hide lessons' : `Start (${c.lessons.length} lessons)`}
            </button>
            {open === c._id && (
              <div className="lessons">
                {c.lessons.map((l, i) => <div key={i}><h3>{i + 1}. {l.title}</h3><p>{l.body}</p></div>)}
                {user
                  ? <button className={`btn ${done(c._id) ? 'done' : ''}`} disabled={done(c._id)} onClick={() => complete(c._id)}>{done(c._id) ? '✔ Completed' : 'Mark as complete'}</button>
                  : <p className="mute">Log in to save your progress.</p>}
              </div>
            )}
          </article>
        ))}
      </div>
    </>
  );
}
