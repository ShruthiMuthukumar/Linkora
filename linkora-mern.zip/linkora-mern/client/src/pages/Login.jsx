import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api';

export default function Login({ onAuth }) {
  const [mode, setMode] = useState('login');
  const [f, setF] = useState({ name: '', email: '', password: '', location: '' });
  const [err, setErr] = useState('');
  const nav = useNavigate();
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setErr('');
    try {
      onAuth(await api(`/auth/${mode}`, { method: 'POST', body: f }));
      nav('/');
    } catch (x) { setErr(x.message); }
  };

  return (
    <div className="card narrow">
      <h1>{mode === 'login' ? 'Welcome back' : 'Create your free account'}</h1>
      <form onSubmit={submit}>
        {mode === 'register' && (<>
          <label>Your name<input value={f.name} onChange={set('name')} required autoComplete="name" /></label>
          <label>Town or city<input value={f.location} onChange={set('location')} autoComplete="address-level2" /></label>
        </>)}
        <label>Email<input type="email" value={f.email} onChange={set('email')} required autoComplete="email" /></label>
        <label>Password (6 or more characters)<input type="password" value={f.password} onChange={set('password')} required minLength={6} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} /></label>
        {err && <p className="error" role="alert">{err}</p>}
        <button className="btn big">{mode === 'login' ? 'Log in' : 'Sign up'}</button>
      </form>
      <button className="link" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>
        {mode === 'login' ? 'New here? Create an account' : 'Already have an account? Log in'}
      </button>
    </div>
  );
}
