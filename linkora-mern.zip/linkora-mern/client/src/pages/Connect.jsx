import { useCallback, useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';

// Picture vocabulary: communicate without needing to type
const STICKERS = ['👍', '❤️', '😊', '🙏', '🎉', '💪', '🏠', '🍲', '🚌', '💼', '📚', '📞', '❓', '✅', '⏰', '💧'];

export default function Connect({ user }) {
  const [tab, setTab] = useState('wall');
  if (!user) return <div className="card narrow"><h1>Connect with others</h1><p>Log in to share pictures and chat.</p><Link className="btn" to="/login">Log in</Link></div>;
  return (
    <>
      <h1>Connect</h1>
      <div className="tabs" role="tablist">
        <button role="tab" aria-selected={tab === 'wall'} onClick={() => setTab('wall')}>🖼️ Community wall</button>
        <button role="tab" aria-selected={tab === 'chat'} onClick={() => setTab('chat')}>💬 Chat</button>
      </div>
      {tab === 'wall' ? <Wall /> : <Chat user={user} />}
    </>
  );
}

function StickerBar({ onPick, label }) {
  return (
    <div className="stickers" role="group" aria-label={label}>
      {STICKERS.map((s) => <button type="button" key={s} onClick={() => onPick(s)} aria-label={`Sticker ${s}`}>{s}</button>)}
    </div>
  );
}

function Wall() {
  const [posts, setPosts] = useState([]);
  const [f, setF] = useState({ text: '', image: '', sticker: '' });
  const [err, setErr] = useState('');
  const load = useCallback(() => api('/posts').then(setPosts).catch((e) => setErr(e.message)), []);
  useEffect(() => { load(); }, [load]);

  const post = async (e) => {
    e.preventDefault(); setErr('');
    try { await api('/posts', { method: 'POST', body: f }); setF({ text: '', image: '', sticker: '' }); load(); }
    catch (x) { setErr(x.message); }
  };
  const like = async (id) => {
    const r = await api(`/posts/${id}/like`, { method: 'POST' });
    setPosts(posts.map((p) => (p.id === id ? { ...p, ...r } : p)));
  };

  return (
    <>
      <form className="card" onSubmit={post}>
        <label>Share an update<textarea value={f.text} maxLength={500} onChange={(e) => setF({ ...f, text: e.target.value })} /></label>
        <label>Picture link (optional)<input type="url" placeholder="https://…" value={f.image} onChange={(e) => setF({ ...f, image: e.target.value })} /></label>
        <p className="mute">Add a sticker {f.sticker && <strong className="chosen">{f.sticker}</strong>}</p>
        <StickerBar label="Choose a sticker" onPick={(s) => setF({ ...f, sticker: f.sticker === s ? '' : s })} />
        {err && <p className="error" role="alert">{err}</p>}
        <button className="btn">Post</button>
      </form>
      {posts.map((p) => (
        <article className="card" key={p.id}>
          <strong>{p.author}</strong> <span className="mute">· {new Date(p.createdAt).toLocaleDateString()}</span>
          {p.text && <p>{p.text}</p>}
          {p.image && <img className="photo" src={p.image} alt="Shared by a member" loading="lazy" referrerPolicy="no-referrer" />}
          {p.sticker && <div className="big-icon" aria-label="Sticker">{p.sticker}</div>}
          <button className={`btn ${p.liked ? 'done' : 'ghost'}`} onClick={() => like(p.id)}>❤️ {p.likes}</button>
        </article>
      ))}
    </>
  );
}

function Chat({ user }) {
  const [people, setPeople] = useState([]);
  const [peer, setPeer] = useState(null);
  const [msgs, setMsgs] = useState([]);
  const [text, setText] = useState('');
  const end = useRef(null);

  useEffect(() => { api('/users').then(setPeople).catch(() => {}); }, []);
  useEffect(() => {
    if (!peer) return;
    const load = () => api(`/messages/${peer.id}`).then(setMsgs).catch(() => {});
    load();
    const t = setInterval(load, 4000);
    return () => clearInterval(t);
  }, [peer]);
  useEffect(() => { end.current && end.current.scrollIntoView({ block: 'end' }); }, [msgs]);

  const send = async (kind, content) => {
    if (!content.trim()) return;
    const m = await api('/messages', { method: 'POST', body: { to: peer.id, kind, content } });
    setMsgs((x) => [...x, m]);
  };

  return (
    <div className="chat">
      <ul className="people" aria-label="People">
        {!people.length && <li className="mute">No one else has joined yet. Invite a friend!</li>}
        {people.map((p) => (
          <li key={p.id}><button className={peer && peer.id === p.id ? 'sel' : ''} onClick={() => setPeer(p)}>
            <span className="av">{p.name[0]}</span> {p.name}<small>{p.location}</small></button></li>
        ))}
      </ul>
      <section className="card convo" aria-live="polite">
        {!peer ? <p className="mute">Choose a person to start chatting.</p> : (<>
          <h2>{peer.name}</h2>
          <div className="msgs">
            {msgs.map((m) => (
              <div key={m._id} className={`msg ${String(m.from) === user.id ? 'mine' : ''} ${m.kind}`}>{m.content}</div>
            ))}
            <div ref={end} />
          </div>
          <StickerBar label="Send a sticker" onPick={(s) => send('sticker', s)} />
          <form className="row" onSubmit={(e) => { e.preventDefault(); send('text', text); setText(''); }}>
            <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a message" aria-label="Message" maxLength={500} />
            <button className="btn">Send</button>
          </form>
        </>)}
      </section>
    </div>
  );
}
