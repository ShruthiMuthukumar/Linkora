import { useEffect, useState } from 'react';
import { NavLink, Route, Routes } from 'react-router-dom';
import { api, getToken, setToken } from './api';
import Jobs from './pages/Jobs.jsx';
import Learn from './pages/Learn.jsx';
import Connect from './pages/Connect.jsx';
import Login from './pages/Login.jsx';

export default function App() {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);

  const refresh = async () => {
    if (!getToken()) return setUser(null);
    try { setUser(await api('/auth/me')); } catch { setToken(null); setUser(null); }
  };
  useEffect(() => { refresh().then(() => setReady(true)); }, []);

  const onAuth = ({ token, user }) => { setToken(token); setUser(user); };
  const logout = () => { setToken(null); setUser(null); };

  if (!ready) return <p className="center">Loading…</p>;

  return (
    <>
      <header className="top">
        <div className="bar">
          <span className="logo">Linkora<i /></span>
          <nav aria-label="Main">
            <NavLink to="/" end><span aria-hidden>💼</span> Jobs</NavLink>
            <NavLink to="/learn"><span aria-hidden>📚</span> Learn</NavLink>
            <NavLink to="/connect"><span aria-hidden>💬</span> Connect</NavLink>
          </nav>
          {user
            ? <button className="btn ghost" onClick={logout}>Log out ({user.name.split(' ')[0]})</button>
            : <NavLink className="btn" to="/login">Log in</NavLink>}
        </div>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<Jobs user={user} />} />
          <Route path="/learn" element={<Learn user={user} refresh={refresh} />} />
          <Route path="/connect" element={<Connect user={user} />} />
          <Route path="/login" element={<Login onAuth={onAuth} />} />
        </Routes>
      </main>
    </>
  );
}
