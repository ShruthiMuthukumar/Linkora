const jwt = require('jsonwebtoken');
const secret = () => process.env.JWT_SECRET || 'dev-secret-change-me';

// Wrap async handlers so errors reach the error middleware
const h = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function read(req) {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  try { return jwt.verify(token, secret()); } catch { return null; }
}
const auth = (req, res, next) => {
  const u = read(req);
  if (!u) return res.status(401).json({ error: 'Please log in first' });
  req.user = u;
  next();
};
const optAuth = (req, res, next) => { req.user = read(req); next(); };
const sign = (u) => jwt.sign({ id: String(u._id) }, secret(), { expiresIn: '7d' });

module.exports = { auth, optAuth, h, sign };
