const r = require('express').Router();
const bcrypt = require('bcryptjs');
const { User } = require('../models');
const { auth, h, sign } = require('../middleware/auth');

const pub = (u) => ({ id: String(u._id), name: u.name, email: u.email, location: u.location, skills: u.skills, completed: u.completed.map(String) });

r.post('/register', h(async (req, res) => {
  const name = String(req.body.name || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!name || !email || password.length < 6)
    return res.status(400).json({ error: 'Enter your name, email and a password of 6 or more characters' });
  if (await User.findOne({ email })) return res.status(409).json({ error: 'This email is already registered' });
  const u = await User.create({ name, email, location: String(req.body.location || '').slice(0, 80), password: await bcrypt.hash(password, 10) });
  res.status(201).json({ token: sign(u), user: pub(u) });
}));

r.post('/login', h(async (req, res) => {
  const u = await User.findOne({ email: String(req.body.email || '').trim().toLowerCase() });
  if (!u || !(await bcrypt.compare(String(req.body.password || ''), u.password)))
    return res.status(401).json({ error: 'Email or password is not correct' });
  res.json({ token: sign(u), user: pub(u) });
}));

r.get('/me', auth, h(async (req, res) => {
  const u = await User.findById(req.user.id);
  if (!u) return res.status(401).json({ error: 'Please log in again' });
  res.json(pub(u));
}));

module.exports = r;
