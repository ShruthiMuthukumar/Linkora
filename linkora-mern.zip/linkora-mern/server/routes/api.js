const r = require('express').Router();
const { User, Job, Course, Post, Message } = require('../models');
const { auth, optAuth, h } = require('../middleware/auth');

const esc = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const safeUrl = (s) => (/^https?:\/\/\S+$/.test(s || '') ? s : '');
const bad = (res, msg) => res.status(400).json({ error: msg });
const missing = (res, what) => res.status(404).json({ error: `${what} not found` });

/* ---------- Jobs ---------- */
r.get('/jobs', optAuth, h(async (req, res) => {
  const { q, type } = req.query;
  const f = {};
  if (type) f.type = String(type);
  if (q) { const re = new RegExp(esc(q), 'i'); f.$or = [{ title: re }, { company: re }, { location: re }, { skills: re }]; }
  const jobs = await Job.find(f).sort('-createdAt').limit(100);
  res.json(jobs.map((j) => {
    const o = j.toObject();
    return { ...o, applicants: undefined, applicantCount: j.applicants.length,
      applied: !!req.user && j.applicants.some((a) => String(a) === req.user.id) };
  }));
}));

r.post('/jobs', auth, h(async (req, res) => {
  const { title, company } = req.body;
  if (!title || !company) return bad(res, 'Job title and company are required');
  const job = await Job.create({ ...req.body, applicants: [], postedBy: req.user.id });
  res.status(201).json(job);
}));

r.post('/jobs/:id/apply', auth, h(async (req, res) => {
  const job = await Job.findByIdAndUpdate(req.params.id, { $addToSet: { applicants: req.user.id } }, { new: true });
  if (!job) return missing(res, 'Job');
  res.json({ applied: true, applicantCount: job.applicants.length });
}));

/* ---------- Courses ---------- */
r.get('/courses', h(async (req, res) => res.json(await Course.find().sort('category title'))));

r.post('/courses/:id/complete', auth, h(async (req, res) => {
  const c = await Course.findById(req.params.id);
  if (!c) return missing(res, 'Course');
  await User.findByIdAndUpdate(req.user.id, { $addToSet: { completed: c._id } });
  res.json({ ok: true });
}));

/* ---------- Community wall (pictures + stickers) ---------- */
r.get('/posts', optAuth, h(async (req, res) => {
  const posts = await Post.find().sort('-createdAt').limit(50).populate('author', 'name');
  res.json(posts.map((p) => ({
    id: String(p._id), author: p.author ? p.author.name : 'Member', text: p.text, image: p.image,
    sticker: p.sticker, likes: p.likes.length, createdAt: p.createdAt,
    liked: !!req.user && p.likes.some((l) => String(l) === req.user.id),
  })));
}));

r.post('/posts', auth, h(async (req, res) => {
  const text = String(req.body.text || '').slice(0, 500);
  const image = safeUrl(req.body.image);
  const sticker = String(req.body.sticker || '').slice(0, 8);
  if (!text && !image && !sticker) return bad(res, 'Add some text, a picture link or a sticker');
  const p = await Post.create({ author: req.user.id, text, image, sticker });
  res.status(201).json({ id: String(p._id) });
}));

r.post('/posts/:id/like', auth, h(async (req, res) => {
  const p = await Post.findById(req.params.id);
  if (!p) return missing(res, 'Post');
  const i = p.likes.findIndex((l) => String(l) === req.user.id);
  if (i >= 0) p.likes.splice(i, 1); else p.likes.push(req.user.id);
  await p.save();
  res.json({ likes: p.likes.length, liked: i < 0 });
}));

/* ---------- Visual chat ---------- */
r.get('/users', auth, h(async (req, res) => {
  const users = await User.find({ _id: { $ne: req.user.id } }).select('name location').limit(100);
  res.json(users.map((u) => ({ id: String(u._id), name: u.name, location: u.location })));
}));

r.get('/messages/:uid', auth, h(async (req, res) => {
  const me = req.user.id, other = req.params.uid;
  res.json(await Message.find({ $or: [{ from: me, to: other }, { from: other, to: me }] }).sort('createdAt').limit(200));
}));

r.post('/messages', auth, h(async (req, res) => {
  const { to, kind = 'text', content } = req.body;
  if (!to || !content) return bad(res, 'Choose a person and write a message');
  if (!['text', 'sticker'].includes(kind)) return bad(res, 'Unknown message type');
  if (!(await User.exists({ _id: to }))) return missing(res, 'Person');
  res.status(201).json(await Message.create({ from: req.user.id, to, kind, content: String(content).slice(0, 500) }));
}));

module.exports = r;
