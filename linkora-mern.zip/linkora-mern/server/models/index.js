const { Schema, model } = require('mongoose');
const ref = (name, extra = {}) => ({ type: Schema.Types.ObjectId, ref: name, ...extra });

const User = model('User', new Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true },
  location: { type: String, default: '', maxlength: 80 },
  skills: [String],
  completed: [ref('Course')],
}, { timestamps: true }));

const Job = model('Job', new Schema({
  title: { type: String, required: true, maxlength: 120 },
  company: { type: String, required: true, maxlength: 120 },
  location: { type: String, default: '' },
  type: { type: String, enum: ['full-time', 'part-time', 'daily-wage', 'internship', 'volunteer'], default: 'full-time' },
  pay: { type: String, default: '' },
  description: { type: String, default: '' },
  skills: [String],
  applicants: [ref('User')],
  postedBy: ref('User'),
}, { timestamps: true }));

const Course = model('Course', new Schema({
  title: { type: String, required: true },
  category: { type: String, default: 'General' },
  level: { type: String, enum: ['beginner', 'intermediate'], default: 'beginner' },
  description: String,
  icon: { type: String, default: '📚' },
  lessons: [{ title: String, body: String }],
}, { timestamps: true }));

const Post = model('Post', new Schema({
  author: ref('User', { required: true }),
  text: { type: String, default: '', maxlength: 500 },
  image: { type: String, default: '' },
  sticker: { type: String, default: '', maxlength: 8 },
  likes: [ref('User')],
}, { timestamps: true }));

const Message = model('Message', new Schema({
  from: ref('User', { required: true }),
  to: ref('User', { required: true }),
  kind: { type: String, enum: ['text', 'sticker'], default: 'text' },
  content: { type: String, required: true, maxlength: 500 },
}, { timestamps: true }));

module.exports = { User, Job, Course, Post, Message };
