require('dotenv').config();
const mongoose = require('mongoose');
const { Job, Course } = require('./models');

const jobs = [
  { title: 'Kitchen Helper', company: 'Sunrise Canteen', location: 'Pune', type: 'full-time', pay: '₹14,000/month', skills: ['cooking', 'cleaning'], description: 'Prepare ingredients and keep the kitchen clean. Meals provided. No experience needed.' },
  { title: 'Delivery Partner', company: 'QuickBasket', location: 'Hyderabad', type: 'daily-wage', pay: '₹600–900/day', skills: ['driving', 'maps'], description: 'Deliver groceries nearby. Two-wheeler and phone required.' },
  { title: 'Shop Assistant', company: 'Daily Needs Store', location: 'Lucknow', type: 'part-time', pay: '₹8,000/month', skills: ['customer service', 'counting'], description: 'Help customers, stock shelves and use the billing counter. Training given.' },
  { title: 'Tailoring Trainee', company: 'Stitch Together', location: 'Jaipur', type: 'internship', pay: '₹6,000 stipend', skills: ['sewing'], description: '3-month paid training with a job offer for good performance.' },
  { title: 'Community Health Volunteer', company: 'Care Circle', location: 'Remote / Local', type: 'volunteer', pay: 'Travel costs covered', skills: ['communication', 'first aid'], description: 'Share health information in your neighbourhood. Certificate provided.' },
];

const courses = [
  { title: 'Using a Smartphone for Work', category: 'Digital basics', icon: '📱', description: 'Calls, messages, maps and safe online payments.', lessons: [
    { title: 'Maps and finding addresses', body: 'Open Maps, type the address, tap Directions. Share your live location with someone you trust.' },
    { title: 'Messages and photos', body: 'Send a photo of your work or your ID document in chat. Always check who you are sending it to.' },
    { title: 'Safe payments', body: 'Never share your PIN or OTP with anyone. Banks and employers never ask for them.' } ] },
  { title: 'Job Interview Basics', category: 'Career', icon: '🤝', description: 'What to say and how to prepare.', lessons: [
    { title: 'Introduce yourself', body: 'Say your name, where you live, what work you have done and what you can learn.' },
    { title: 'Common questions', body: 'Why do you want this job? Can you work on time? Practise your answers out loud.' },
    { title: 'On the day', body: 'Arrive 10 minutes early, keep your documents in a folder and ask when you will hear back.' } ] },
  { title: 'Money and Saving', category: 'Life skills', icon: '💰', description: 'Plan wages, save a little, avoid scams.', lessons: [
    { title: 'Track what you earn', body: 'Write down money in and money out each week. Even a notebook works.' },
    { title: 'Start a small saving', body: 'Save a fixed small amount on the day you are paid, before spending.' },
    { title: 'Spot a scam', body: 'If someone asks you to pay to get a job, it is almost always a scam.' } ] },
];

(async () => {
  await mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/linkora');
  await Job.deleteMany({}); await Course.deleteMany({});
  await Job.insertMany(jobs); await Course.insertMany(courses);
  console.log(`Seeded ${jobs.length} jobs and ${courses.length} courses`);
  await mongoose.disconnect();
})();
