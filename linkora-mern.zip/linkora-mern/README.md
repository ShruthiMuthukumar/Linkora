# Linkora

A MERN-stack platform that helps underprivileged people **find jobs**, **learn skills** and **communicate visually**
(stickers, pictures and simple chat) without needing strong reading or typing skills.

**Stack:** MongoDB · Express · React (Vite) · Node.js · REST API (JWT auth)

## Run it
Prerequisites: Node 18+ and MongoDB running locally (or an Atlas URI).

```bash
npm run install:all
cp server/.env.example server/.env     # set JWT_SECRET and MONGO_URI
npm run seed                           # sample jobs and courses
npm run dev                            # API :5000, app :5173
```

## Features
- **Jobs:** search by title, place or skill; filter by type (daily-wage, part-time, volunteer…); apply with one tap.
- **Learn:** short plain-language courses; mark complete and track progress on your profile.
- **Connect:** community wall (text, picture link, sticker, likes) and one-to-one chat with a sticker vocabulary.
- **Accessible by design:** large touch targets, 18px base text, icons beside labels, high contrast, dark mode, keyboard focus, reduced motion.

## REST API (`/api`)
| Method | Path | Auth | Purpose |
|---|---|---|---|
| POST | /auth/register, /auth/login | – | Create account / log in (returns JWT) |
| GET | /auth/me | yes | Current user and completed courses |
| GET | /jobs?q=&type= | optional | Search jobs |
| POST | /jobs | yes | Post a job |
| POST | /jobs/:id/apply | yes | Apply |
| GET | /courses | – | List courses with lessons |
| POST | /courses/:id/complete | yes | Mark course complete |
| GET / POST | /posts | POST needs auth | Community wall |
| POST | /posts/:id/like | yes | Toggle like |
| GET | /users | yes | People to chat with |
| GET / POST | /messages(/:uid) | yes | Chat history / send text or sticker |

## Structure
```
server/  server.js · models/ · routes/ (auth, api) · middleware/auth.js · seed.js
client/  src/App.jsx · api.js · pages/ (Jobs, Learn, Connect, Login) · styles.css
```

## Next steps
Employer accounts and job management, image upload (Cloudinary/S3), real-time chat with Socket.IO,
video lessons, multi-language UI with voice read-aloud, SMS/WhatsApp job alerts, rate limiting and helmet for production.
